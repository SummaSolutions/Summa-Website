
Drupal module: Variable API Database storage
============================================
Provides database storage for realm variables.

This module provides some CRUD API to store and read your custom variables
and some _set() and _get() methods that are tightly integrated with Variable Realms

An example of a module using this API is Internationalization's i18n_variable module.