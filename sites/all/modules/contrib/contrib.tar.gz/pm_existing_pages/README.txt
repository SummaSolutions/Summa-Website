
-- SUMMARY --

For a full description of the module, visit the project page:
  http://drupal.org/project/pm_existing_pages
  
To submit bug reports and feature suggestions, or to track changes:
  http://drupal.org/project/issues/pm_existing_pages
  
-- INSTALLATION --

Install the module as usual, more info can be found on
http://drupal.org/documentation/install/modules-themes/modules-7
You should also install Panels, which is not a dependency for this module
but is the recommended module to start overriding page layouts.
Panels can be found at http://drupal.org/project/panels

-- USAGE --

On admin > structure > pages click "add existing page".
There you can override your page. If you don't know the exact path
you override, there is a search box below. Just start to type
and it will automatically find what you want.
Once you have done this you should go back to admin > structure > pages
and enable the page you just created.
  

-- MAINTAINERS --

swentel - http://drupal.org/user/107403
